Install https://github.com/raphael/adam-vim 

This repo is about playing with Boxen, cloning https://github.com/raphael/adam-vim project to bootstrap a precanned vim environment. 

This is hardcoded to my environment @see manifests/init.pp 

## Usage

include 'vim'

## Required Puppet Modules

* `boxen`

